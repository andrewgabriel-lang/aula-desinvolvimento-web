﻿import express from 'express';
import cors from 'cors';
const app = express();
app.use(cors());
app.use(express.json());
/* AQUI VAI MEU CRUD DE PRODUTOS */
const produtos = [];
/* Adicionano objetos no vetor produtos */
const p1 = {
    id: 1,
    nome: 'Alienware',
    tipo: 'notebook',
    status: 'disponivel',
    descricao: 'Notebook para processamento elevado'
}
const p2 = {
    id: 2,
    nome: 'Chromebook 14',
    tipo: 'notebook',
    status: 'manutencao',
    descricao: 'Notebook leve e portátil'
}
const p3 = {
    id: 3,
    nome: 'Epson Power Lite W39',
    tipo: 'projetor',
    status: 'emprestado',
    descricao: 'Projetor para apresentações'
}
const p4 = {
    id: 4,
    nome: 'Lenovo ThinkPad',
    tipo: 'notebook',
    status: 'disponivel',
    descricao: 'Notebook robusto para uso corporativo'
}
const p5 = {
    id: 5,
    nome: 'Acer Aspire 3',
    tipo: 'notebook',
    status: 'disponivel',
    descricao: 'Notebook econômico para estudo'
}
const p6 = {
    id: 6,
    nome: 'Sony VPL-HW45ES',
    tipo: 'projetor',
    status: 'manutencao',
    descricao: 'Projetor Full HD para cinema em casa'
}
const p7 = {
    id: 7,
    nome: 'Dell Latitude',
    tipo: 'notebook',
    status: 'emprestado',
    descricao: 'Notebook empresarial com bateria de longa duração'
}
const p8 = {
    id: 8,
    nome: 'BenQ MH733',
    tipo: 'projetor',
    status: 'disponivel',
    descricao: 'Projetor profissional para sala de reunião'
}
const p9 = {
    id: 9,
    nome: 'HP Pavilion',
    tipo: 'notebook',
    status: 'disponivel',
    descricao: 'Notebook com tela de alta definição'
}
const p10 = {
    id: 10,
    nome: 'ViewSonic PA503W',
    tipo: 'projetor',
    status: 'emprestado',
    descricao: 'Projetor para aulas e apresentações'
}
produtos.push(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
const validStatus = ['disponivel', 'emprestado', 'manutencao'];
/* Endpoint para listar todos os produtos */
app.get('/produtos', (req, res) => {
    const { status, tipo, busca, descricao } = req.query;
    let resultado = produtos;
    if (status) resultado = resultado.filter(p => p.status === status);
    if (tipo) resultado = resultado.filter(p => p.tipo === tipo);
    if (busca) resultado = resultado.filter(p => p.nome.toLowerCase().includes(busca.toLowerCase()));
    if (descricao) resultado = resultado.filter(p => p.descricao.toLowerCase().includes(descricao.toLowerCase()));
    res.json(resultado);
});
app.get('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        return res.status(400).json({ error: 'ID inválido.' });
    }
    const produto = produtos.find((p) => p.id === id);
    if (!produto) {
        return res.status(404).json({ error: 'Produto não encontrado.' });
    }
    res.json(produto);
});
app.post('/produtos', (req, res) => {
    const { nome, tipo, status, descricao } = req.body;
    if (!nome || !tipo) {
        return res.status(400).json({ error: 'Nome e tipo são obrigatórios.' });
    }
    if (status && !validStatus.includes(status)) {
        return res.status(400).json({ error: 'Status inválido. Use disponivel, emprestado ou manutencao.' });
    }
    const novoId = Math.max(0, ...produtos.map((p) => p.id)) + 1;
    const produto = {
        id: novoId,
        nome,
        tipo,
        status: status || 'disponivel',
        descricao: descricao || '',
    };
    produtos.push(produto);
    res.status(201).json(produto);
});
app.put('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        return res.status(400).json({ error: 'ID inválido.' });
    }
    const produto = produtos.find((p) => p.id === id);
    if (!produto) {
        return res.status(404).json({ error: 'Produto não encontrado.' });
    }
    const { nome, tipo, status, descricao } = req.body;
    if (nome !== undefined && !nome) {
        return res.status(400).json({ error: 'Nome não pode ser vazio.' });
    }
    if (tipo !== undefined && !tipo) {
        return res.status(400).json({ error: 'Tipo não pode ser vazio.' });
    }
    if (status !== undefined && !validStatus.includes(status)) {
        return res.status(400).json({ error: 'Status inválido. Use disponivel, emprestado ou manutencao.' });
    }
    produto.nome = nome !== undefined ? nome : produto.nome;
    produto.tipo = tipo !== undefined ? tipo : produto.tipo;
    produto.status = status !== undefined ? status : produto.status;
    produto.descricao = descricao !== undefined ? descricao : produto.descricao;
    res.json(produto);
});
app.delete('/produtos/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        return res.status(400).json({ error: 'ID inválido.' });
    }
    const index = produtos.findIndex((p) => p.id === id);
    if (index === -1) {
        return res.status(404).json({ error: 'Produto não encontrado.' });
    }
    produtos.splice(index, 1);
    res.status(204).send();
});
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
