﻿const baseUrl = 'http://localhost:3000';
const tbody = document.querySelector('#data');
const messageBox = document.querySelector('#message');
const form = document.querySelector('#product-form');
const productIdInput = document.querySelector('#produtoId');
const formNome = document.querySelector('#productNome');
const formTipo = document.querySelector('#productTipo');
const formStatus = document.querySelector('#productStatus');
const formDescricao = document.querySelector('#productDescricao');
const filterNome = document.querySelector('#filterNome');
const filterDescricao = document.querySelector('#filterDescricao');
const filterTipo = document.querySelector('#filterTipo');
const filterStatus = document.querySelector('#filterStatus');
const saveButton = document.querySelector('#salvar');
const cancelButton = document.querySelector('#cancelar');
let editingProductId = null;
const showMessage = (text, type = 'success') => {
    messageBox.textContent = text;
    messageBox.className = type;
    messageBox.style.display = 'block';
    setTimeout(() => {
        if (messageBox.textContent === text) {
            messageBox.style.display = 'none';
        }
    }, 5000);
};
const setFormMode = (editing = false) => {
    editingProductId = editing ? Number(productIdInput.value) : null;
    saveButton.textContent = editing ? 'Atualizar' : 'Salvar';
    cancelButton.hidden = !editing;
};
const clearForm = () => {
    form.reset();
    productIdInput.value = '';
    setFormMode(false);
};
const buildQueryParams = () => {
    const params = new URLSearchParams();
    if (filterTipo.value) params.append('tipo', filterTipo.value);
    if (filterStatus.value) params.append('status', filterStatus.value);
    if (filterNome.value) params.append('busca', filterNome.value);
    if (filterDescricao.value) params.append('descricao', filterDescricao.value);
    return params.toString();
};
const renderProducts = (products) => {
    tbody.innerHTML = '';
    if (!products.length) {
        tbody.innerHTML = '<tr><td colspan="6">Nenhum produto encontrado.</td></tr>';
        return;
    }
    for (const p of products) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${p.id}</td>
            <td>${p.nome}</td>
            <td>${p.tipo}</td>
            <td>${p.status}</td>
            <td>${p.descricao || ''}</td>
            <td>
                <button class="edit-button" data-id="${p.id}">Editar</button>
                <button class="delete-button" data-id="${p.id}">Excluir</button>
            </td>
        `;
        tbody.appendChild(tr);
    }
    document.querySelectorAll('.edit-button').forEach((button) => {
        button.addEventListener('click', () => loadProductToForm(button.dataset.id));
    });
    document.querySelectorAll('.delete-button').forEach((button) => {
        button.addEventListener('click', () => deleteProduct(button.dataset.id));
    });
};
const getProducts = async () => {
    try {
        const query = buildQueryParams();
        const url = `${baseUrl}/produtos${query ? `?${query}` : ''}`;
        const response = await fetch(url);
        if (!response.ok) {
            showMessage('Erro ao buscar produtos.', 'error');
            return;
        }
        const products = await response.json();
        renderProducts(products);
    } catch (error) {
        showMessage('Erro de conexão com o servidor.', 'error');
    }
};
const loadProductToForm = async (id) => {
    try {
        const response = await fetch(`${baseUrl}/produtos/${id}`);
        if (!response.ok) {
            showMessage('Produto não encontrado.', 'error');
            return;
        }
        const product = await response.json();
        productIdInput.value = product.id;
        formNome.value = product.nome;
        formTipo.value = product.tipo;
        formStatus.value = product.status;
        formDescricao.value = product.descricao || '';
        setFormMode(true);
    } catch (error) {
        showMessage('Erro ao carregar produto.', 'error');
    }
};
const deleteProduct = async (id) => {
    if (!confirm('Deseja excluir este produto?')) {
        return;
    }
    try {
        const response = await fetch(`${baseUrl}/produtos/${id}`, {
            method: 'DELETE',
        });
        if (response.status === 204) {
            showMessage('Produto excluído com sucesso.');
            clearForm();
            getProducts();
            return;
        }
        const errorBody = await response.json();
        showMessage(errorBody.error || 'Erro ao excluir produto.', 'error');
    } catch (error) {
        showMessage('Erro de conexão ao excluir.', 'error');
    }
};
const submitForm = async (event) => {
    event.preventDefault();
    const payload = {
        nome: formNome.value.trim(),
        tipo: formTipo.value,
        status: formStatus.value,
        descricao: formDescricao.value.trim(),
    };
    if (!payload.nome || !payload.tipo) {
        showMessage('Nome e tipo são obrigatórios.', 'error');
        return;
    }
    const url = editingProductId ? `${baseUrl}/produtos/${editingProductId}` : `${baseUrl}/produtos`;
    const method = editingProductId ? 'PUT' : 'POST';
    try {
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });
        const result = await response.json().catch(() => null);
        if (response.ok) {
            showMessage(editingProductId ? 'Produto atualizado com sucesso.' : 'Produto criado com sucesso.');
            clearForm();
            getProducts();
            return;
        }
        showMessage(result?.error || 'Erro na operação.', 'error');
    } catch (error) {
        showMessage('Erro de conexão ao salvar produto.', 'error');
    }
};
form.addEventListener('submit', submitForm);
cancelButton.addEventListener('click', clearForm);
document.querySelector('#filtrar').addEventListener('click', getProducts);
getProducts();
